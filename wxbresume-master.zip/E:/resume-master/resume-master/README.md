# resume

> Personal Resume(个人简历)

> 主要使用vue 和 animate.css 制作个人在线简历，效果比较接近于H5页面,支持鼠标滑动切换

### 演示（请忽略渣渲染）

![resume.gif](https://github.com/lyttonlee/pic/blob/master/resume.gif?raw=true)

### 在线地址

githubPages: https://lyttonlee.github.io/

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
